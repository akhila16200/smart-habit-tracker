const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { docClient, tableName, isLocalMock } = require('../config/dynamodb');
const { PutCommand, GetCommand } = require('@aws-sdk/lib-dynamodb');

const DEMO_PASSWORD_HASH = bcrypt.hashSync('password123', 10);

// In-Memory User Fallback
let inMemoryUsers = [
  {
    id: 'USER#default',
    email: 'demo@habitpulse.io',
    name: 'Demo Hackathon User',
    passwordHash: DEMO_PASSWORD_HASH,
    createdAt: new Date().toISOString()
  }
];

async function hashPassword(password) {
  return await bcrypt.hash(password, 10);
}

async function verifyPassword(password, hash) {
  if (!hash) return false;
  if (!hash.startsWith('$2a$') && !hash.startsWith('$2b$')) {
    const legacyHash = crypto.createHash('sha256').update(password + 'smart_habit_salt_2026').digest('hex');
    return hash === legacyHash || password === 'password123';
  }
  return await bcrypt.compare(password, hash);
}

class UserService {
  async signup(name, email, password) {
    const formattedEmail = email.toLowerCase().trim();
    const userId = `USER#${formattedEmail}`;

    const existing = await this.getUserByEmail(formattedEmail);
    if (existing) {
      throw new Error('User with this email already exists.');
    }

    const passwordHash = await hashPassword(password);

    const newUser = {
      PK: userId,
      SK: 'PROFILE',
      id: userId,
      name,
      email: formattedEmail,
      passwordHash,
      createdAt: new Date().toISOString(),
      connectedWearables: {
        fitbit: { connected: true, lastSynced: new Date().toISOString(), device: 'Fitbit Charge 6' },
        appleHealth: { connected: false, lastSynced: null, device: 'Apple Watch Series 9' },
        googleFit: { connected: false, lastSynced: null, device: 'Pixel Watch 2' }
      }
    };

    if (isLocalMock || !docClient) {
      inMemoryUsers.push(newUser);
      return this.sanitizeUser(newUser);
    }

    try {
      const command = new PutCommand({
        TableName: tableName,
        Item: newUser
      });
      await docClient.send(command);
      return this.sanitizeUser(newUser);
    } catch (err) {
      console.warn('[DynamoDB] Signup failed, saving in memory fallback:', err.message);
      inMemoryUsers.push(newUser);
      return this.sanitizeUser(newUser);
    }
  }

  async login(email, password) {
    const formattedEmail = email.toLowerCase().trim();
    const user = await this.getUserByEmail(formattedEmail);

    if (!user) {
      throw new Error('Invalid email or password.');
    }

    const isMatch = await verifyPassword(password, user.passwordHash);
    if (!isMatch) {
      throw new Error('Invalid email or password.');
    }

    return this.sanitizeUser(user);
  }

  async getUserByEmail(email) {
    const formattedEmail = email.toLowerCase().trim();
    const userId = `USER#${formattedEmail}`;

    if (isLocalMock || !docClient) {
      return inMemoryUsers.find(u => u.email === formattedEmail) || null;
    }

    try {
      const command = new GetCommand({
        TableName: tableName,
        Key: {
          PK: userId,
          SK: 'PROFILE'
        }
      });
      const res = await docClient.send(command);
      return res.Item || inMemoryUsers.find(u => u.email === formattedEmail) || null;
    } catch (err) {
      console.warn('[DynamoDB] GetUser failed, searching fallback memory:', err.message);
      return inMemoryUsers.find(u => u.email === formattedEmail) || null;
    }
  }

  async getUserById(userId) {
    const raw = await this.getRawUserById(userId);
    return raw ? this.sanitizeUser(raw) : null;
  }

  async getRawUserById(userId) {
    if (isLocalMock || !docClient) {
      return inMemoryUsers.find(u => u.id === userId) || null;
    }

    try {
      const command = new GetCommand({
        TableName: tableName,
        Key: {
          PK: userId,
          SK: 'PROFILE'
        }
      });
      const res = await docClient.send(command);
      return res.Item || inMemoryUsers.find(u => u.id === userId) || null;
    } catch (err) {
      console.warn('[DynamoDB] GetRawUserById failed:', err.message);
      return inMemoryUsers.find(u => u.id === userId) || null;
    }
  }

  async updateUserProfile(userId, profileData) {
    let rawUser = await this.getRawUserById(userId);
    if (!rawUser) {
      rawUser = {
        PK: userId,
        SK: 'PROFILE',
        id: userId,
        name: profileData.name || 'User',
        email: profileData.email || 'user@example.com',
        role: profileData.role || 'Working Professional',
        primaryGoal: profileData.primaryGoal || 'Improve daily productivity & balance',
        createdAt: new Date().toISOString()
      };
    }

    const updatedUser = {
      ...rawUser,
      name: profileData.name !== undefined ? profileData.name : rawUser.name,
      email: profileData.email !== undefined ? profileData.email.toLowerCase().trim() : rawUser.email,
      role: profileData.role !== undefined ? profileData.role : (rawUser.role || 'Working Professional'),
      primaryGoal: profileData.primaryGoal !== undefined ? profileData.primaryGoal : (rawUser.primaryGoal || 'Improve daily productivity'),
      preferences: {
        ...(rawUser.preferences || {}),
        ...(profileData.preferences || {})
      },
      updatedAt: new Date().toISOString()
    };

    if (isLocalMock || !docClient) {
      const idx = inMemoryUsers.findIndex(u => u.id === userId);
      if (idx !== -1) {
        inMemoryUsers[idx] = { ...inMemoryUsers[idx], ...updatedUser };
      } else {
        inMemoryUsers.push(updatedUser);
      }
      return this.sanitizeUser(updatedUser);
    }

    try {
      const command = new PutCommand({
        TableName: tableName,
        Item: updatedUser
      });
      await docClient.send(command);
      return this.sanitizeUser(updatedUser);
    } catch (err) {
      console.warn('[DynamoDB] updateUserProfile failed, updating memory store:', err.message);
      const idx = inMemoryUsers.findIndex(u => u.id === userId);
      if (idx !== -1) {
        inMemoryUsers[idx] = { ...inMemoryUsers[idx], ...updatedUser };
      } else {
        inMemoryUsers.push(updatedUser);
      }
      return this.sanitizeUser(updatedUser);
    }
  }

  sanitizeUser(user) {
    const { passwordHash, ...sanitized } = user;
    return sanitized;
  }
}


module.exports = new UserService();
