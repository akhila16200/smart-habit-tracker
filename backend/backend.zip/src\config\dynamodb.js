const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient } = require('@aws-sdk/lib-dynamodb');
require('dotenv').config();

const region = process.env.AWS_REGION || 'us-east-1';
const tableName = process.env.DYNAMODB_TABLE_NAME || 'SmartHabitsTracker';
const isLocalMock = process.env.USE_LOCAL_MOCK === 'true';

let docClient = null;

if (!isLocalMock) {
  try {
    const config = { region };
    if (process.env.DYNAMODB_ENDPOINT) {
      config.endpoint = process.env.DYNAMODB_ENDPOINT;
    }

    const client = new DynamoDBClient(config);
    docClient = DynamoDBDocumentClient.from(client, {
      marshallOptions: {
        removeUndefinedValues: true,
        convertClassInstanceToMap: true,
      },
    });
    console.log(`[DynamoDB] Initialized client for table "${tableName}" in region "${region}"`);
  } catch (error) {
    console.warn('[DynamoDB] Could not initialize AWS DynamoDB Client. Falling back to local mock mode.', error.message);
  }
} else {
  console.log('[DynamoDB] Running in Local Mock Mode (In-Memory Data Store)');
}

module.exports = {
  docClient,
  tableName,
  isLocalMock,
};
