const habitService = require('../services/habitService');

exports.getDashboardAnalytics = async (req, res) => {
  try {
    const userId = req.headers['x-user-id'] || req.query.userId || 'USER#default';
    const habits = await habitService.getHabits(userId);
    const todayStr = new Date().toISOString().split('T')[0];

    const totalHabits = habits.length;
    let completedToday = 0;
    let maxStreak = 0;
    let totalCheckIns = 0;

    // Category Breakdown Tracking for the 4 target categories: Fitness, Mindfulness, Learning, Personal
    const targetCategories = ['Fitness', 'Mindfulness', 'Learning', 'Personal'];
    const categoryStats = {
      Fitness: { total: 0, completed: 0, rate: 0, color: '#10B981' },
      Mindfulness: { total: 0, completed: 0, rate: 0, color: '#06B6D4' },
      Learning: { total: 0, completed: 0, rate: 0, color: '#F59E0B' },
      Personal: { total: 0, completed: 0, rate: 0, color: '#EC4899' },
    };

    let totalTargetHabits = 0;
    let completedTargetHabits = 0;

    // Heatmap date mapping for last 30 days
    const heatmapMap = {};
    for (let i = 29; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000);
      const dateStr = d.toISOString().split('T')[0];
      heatmapMap[dateStr] = 0;
    }

    habits.forEach(h => {
      if (h.currentStreak > maxStreak) {
        maxStreak = h.currentStreak;
      }
      totalCheckIns += (h.totalCheckIns || 0);

      const isCheckedToday = (h.checkInHistory || []).some(entry => entry.date === todayStr);
      if (isCheckedToday) {
        completedToday++;
      }

      // Track target category breakdown
      const catKey = targetCategories.find(c => c.toLowerCase() === (h.category || '').toLowerCase());
      if (catKey) {
        categoryStats[catKey].total += 1;
        totalTargetHabits += 1;
        if (isCheckedToday) {
          categoryStats[catKey].completed += 1;
          completedTargetHabits += 1;
        }
      }

      (h.checkInHistory || []).forEach(entry => {
        if (heatmapMap[entry.date] !== undefined) {
          heatmapMap[entry.date] += 1;
        }
      });
    });

    // Calculate rates per category
    Object.keys(categoryStats).forEach(cat => {
      const s = categoryStats[cat];
      s.rate = s.total > 0 ? Math.round((s.completed / s.total) * 100) : 0;
    });

    // Overall Productivity Score across the 4 categories
    const productivityScore = totalTargetHabits > 0
      ? Math.round((completedTargetHabits / totalTargetHabits) * 100)
      : (totalHabits > 0 ? Math.round((completedToday / totalHabits) * 100) : 100);

    // Dynamic Badge Assignment based on exact user prompt rules
    let productivityStatus = { label: 'Poor', icon: '🛑', color: '#EF4444', badgeClass: 'status-poor' };
    if (productivityScore === 100) {
      productivityStatus = { label: 'Excellent', icon: '🌟', color: '#10B981', badgeClass: 'status-excellent' };
    } else if (productivityScore >= 70) {
      productivityStatus = { label: 'Good', icon: '👍', color: '#3B82F6', badgeClass: 'status-good' };
    } else if (productivityScore >= 40) {
      productivityStatus = { label: 'Low', icon: '⚠️', color: '#F59E0B', badgeClass: 'status-low' };
    } else {
      productivityStatus = { label: 'Poor', icon: '🛑', color: '#EF4444', badgeClass: 'status-poor' };
    }

    const heatmap = Object.keys(heatmapMap).map(date => {
      const count = heatmapMap[date];
      let level = 0;
      if (count === 1) level = 1;
      else if (count === 2) level = 2;
      else if (count >= 3) level = 3;
      return { date, count, level };
    });

    // Achievement Badges
    const badges = [
      { id: 'b1', title: 'First Step', desc: 'Create your first habit', earned: totalHabits >= 1, icon: '🌱' },
      { id: 'b2', title: 'Streak Starter', desc: 'Reach a 3-day streak', earned: maxStreak >= 3, icon: '🔥' },
      { id: 'b3', title: 'Unstoppable Momentum', desc: 'Reach a 7-day streak', earned: maxStreak >= 7, icon: '⚡' },
      { id: 'b4', title: 'Century Club', desc: 'Log 10+ total check-ins', earned: totalCheckIns >= 10, icon: '🏆' },
      { id: 'b5', title: 'Micro-Goal Master', desc: 'Maintain 3 active habits', earned: totalHabits >= 3, icon: '🎯' }
    ];

    res.json({
      success: true,
      data: {
        totalHabits,
        completedToday,
        maxStreak,
        totalCheckIns,
        completionRate: totalHabits > 0 ? Math.round((completedToday / totalHabits) * 100) : 0,
        productivityScoreboard: {
          score: productivityScore,
          status: productivityStatus,
          totalTargetHabits,
          completedTargetHabits,
          categoryStats
        },
        heatmap,
        badges
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
