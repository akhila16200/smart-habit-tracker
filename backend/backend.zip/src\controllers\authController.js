const userService = require('../services/userService');

exports.signup = async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ success: false, message: 'Name, email, and password are required.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ success: false, message: 'Password must be at least 6 characters long.' });
    }

    const user = await userService.signup(name, email, password);
    res.status(201).json({
      success: true,
      message: 'Account created successfully!',
      data: {
        user,
        token: `token-${user.id}`
      }
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password are required.' });
    }

    const user = await userService.login(email, password);
    res.json({
      success: true,
      message: 'Login successful!',
      data: {
        user,
        token: `token-${user.id}`
      }
    });
  } catch (error) {
    res.status(401).json({ success: false, message: error.message });
  }
};

exports.getMe = async (req, res) => {
  try {
    const userId = req.headers['x-user-id'] || 'USER#default';
    const user = await userService.getUserById(userId);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    res.json({ success: true, data: user });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.updateProfile = async (req, res) => {
  try {
    const userId = req.headers['x-user-id'] || req.body.userId || 'USER#default';
    const updatedUser = await userService.updateUserProfile(userId, req.body);
    res.json({
      success: true,
      message: 'Profile updated successfully!',
      data: updatedUser
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

