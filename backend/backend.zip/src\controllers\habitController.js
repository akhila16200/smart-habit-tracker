const habitService = require('../services/habitService');
const { generateMicroGoals } = require('../services/aiService');

function getUserId(req) {
  return req.headers['x-user-id'] || req.query.userId || 'USER#default';
}

exports.getHabits = async (req, res) => {
  try {
    const userId = getUserId(req);
    const habits = await habitService.getHabits(userId);
    res.json({ success: true, data: habits });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.getHabitById = async (req, res) => {
  try {
    const userId = getUserId(req);
    const { id } = req.params;
    const habit = await habitService.getHabitById(id, userId);
    if (!habit) {
      return res.status(404).json({ success: false, message: 'Habit not found' });
    }
    res.json({ success: true, data: habit });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.createHabit = async (req, res) => {
  try {
    const userId = getUserId(req);
    const { title, description, category, frequency, targetDays, microGoals } = req.body;
    if (!title) {
      return res.status(400).json({ success: false, message: 'Habit title is required' });
    }

    const newHabit = await habitService.createHabit({
      title,
      description,
      category,
      frequency,
      targetDays,
      microGoals
    }, userId);

    res.status(201).json({ success: true, data: newHabit });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.checkInHabit = async (req, res) => {
  try {
    const userId = getUserId(req);
    const { id } = req.params;
    const updatedHabit = await habitService.checkInHabit(id, userId);
    res.json({ success: true, data: updatedHabit });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.toggleMicroGoal = async (req, res) => {
  try {
    const userId = getUserId(req);
    const { id, microGoalId } = req.params;
    const updatedHabit = await habitService.toggleMicroGoal(id, microGoalId, userId);
    res.json({ success: true, data: updatedHabit });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.deleteHabit = async (req, res) => {
  try {
    const userId = getUserId(req);
    const { id } = req.params;
    const result = await habitService.deleteHabit(id, userId);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.suggestMicroGoals = async (req, res) => {
  try {
    const { title, category } = req.body;
    const suggestions = generateMicroGoals(title || 'New Habit', category || 'default');
    res.json({ success: true, data: suggestions });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.updateHabit = async (req, res) => {
  try {
    const userId = getUserId(req);
    const { id } = req.params;
    const updated = await habitService.updateHabit(id, req.body, userId);
    res.json({ success: true, data: updated });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.generateOnboardingHabits = async (req, res) => {
  try {
    const userId = getUserId(req);
    const profile = req.body || {};
    const createdHabits = await habitService.createOnboardingHabits(profile, userId);
    res.status(201).json({ success: true, data: createdHabits });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

