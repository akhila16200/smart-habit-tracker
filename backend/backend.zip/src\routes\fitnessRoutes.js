const express = require('express');
const router = express.Router();
const fitnessWebhookService = require('../services/fitnessWebhookService');

/**
 * POST /api/webhook/fitness
 * Webhook endpoint for receiving external wearable/fitness platform metrics
 */
router.post('/', async (req, res) => {
  try {
    const payload = req.body;
    if (!payload || Object.keys(payload).length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Invalid payload. Fitness metrics are required in request body.'
      });
    }

    const result = await fitnessWebhookService.processWebhookPayload(payload);
    res.json(result);
  } catch (error) {
    console.error('[Fitness Webhook Error]', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Error processing fitness webhook payload'
    });
  }
});

module.exports = router;
