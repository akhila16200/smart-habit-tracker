const express = require('express');
const router = express.Router();
const habitController = require('../controllers/habitController');

router.get('/', habitController.getHabits);
router.post('/', habitController.createHabit);
router.post('/suggest-microgoals', habitController.suggestMicroGoals);
router.post('/generate-ai-habits', habitController.generateOnboardingHabits);
router.get('/:id', habitController.getHabitById);
router.put('/:id', habitController.updateHabit);
router.post('/:id/checkin', habitController.checkInHabit);
router.post('/:id/microgoals/:microGoalId/toggle', habitController.toggleMicroGoal);
router.delete('/:id', habitController.deleteHabit);

module.exports = router;

