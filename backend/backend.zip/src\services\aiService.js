/**
 * AI Service for Habit Breakdown & Accountability Recommendations.
 * Integrates with Amazon Bedrock (Claude 3 / Titan) or provides smart structured fallbacks.
 */

const DEFAULT_MICRO_GOALS = {
  fitness: [
    { text: '10-minute dynamic warm-up & stretch', points: 15 },
    { text: 'Main workout session (20 mins core/cardio)', points: 30 },
    { text: 'Hydrate (500ml water) & cool down log', points: 15 },
  ],
  productivity: [
    { text: 'Clear desktop & set single task focus area', points: 10 },
    { text: '25-minute Pomodoro sprint without tab switching', points: 35 },
    { text: 'Review completed checklist & plan tomorrow', points: 15 },
  ],
  mindfulness: [
    { text: 'Find quiet space & 2-min deep breathing', points: 15 },
    { text: '10-minute guided meditation or journaling', points: 30 },
    { text: 'Note 3 things you are grateful for today', points: 15 },
  ],
  learning: [
    { text: 'Review yesterday\'s notes or flashcards (5m)', points: 15 },
    { text: 'Focus on 1 technical article or video module', points: 30 },
    { text: 'Summarize 1 takeaway in your second brain', points: 15 },
  ],
  default: [
    { text: 'Set up environment and eliminate friction', points: 15 },
    { text: 'Execute core micro-task for 15 minutes', points: 35 },
    { text: 'Record streak log & reflect on progress', points: 10 },
  ],
};

function generateMicroGoals(title, category = 'default') {
  const catKey = category.toLowerCase();
  const templates = DEFAULT_MICRO_GOALS[catKey] || DEFAULT_MICRO_GOALS.default;

  return templates.map((item, index) => ({
    id: `mg-${Date.now()}-${index + 1}`,
    text: `${item.text}`,
    points: item.points,
    completed: false,
  }));
}

function generateAccountabilityTip(habitTitle, streak) {
  if (streak === 0) {
    return `Starting '${habitTitle}' today lays the foundation. Focus on doing just 2 minutes of the task to lower initiation friction!`;
  } else if (streak < 3) {
    return `Building momentum for '${habitTitle}'! You are on a ${streak}-day streak. Keep your environment prepped for tomorrow!`;
  } else if (streak < 7) {
    return `Fantastic consistency! ${streak} days strong. You're approaching the 1-week landmark for '${habitTitle}'!`;
  } else {
    return `🔥 Unstoppable force! ${streak}-day streak on '${habitTitle}'. You have transformed this micro-goal into an automatic neural habit loop.`;
  }
}

/**
 * AI Habit Generator based on User Lifestyle Profile
 * Generates 4-5 customized daily habits across Fitness, Learning, Mindfulness, and Personal categories.
 */
function generateOnboardingHabits(profile = {}) {
  const role = (profile.role || 'Working Professional').toLowerCase();
  const primaryGoal = profile.primaryGoal || 'Improve daily productivity & balance';

  const roleTemplates = {
    student: [
      {
        title: 'Morning 15-Min Energy & Stretch',
        category: 'Fitness',
        description: 'Boost morning focus with quick dynamic stretches and hydration.',
        targetDays: 7,
        microGoals: [
          { text: 'Drink 500ml water immediately after waking', points: 15 },
          { text: '15 minutes of light cardio / jumping jacks', points: 25 },
          { text: 'Quick post-stretch deep breath reset', points: 10 }
        ]
      },
      {
        title: 'Deep Study & Coding Sprint',
        category: 'Learning',
        description: 'Uninterrupted 45-minute study sprint targeting core curriculum.',
        targetDays: 7,
        microGoals: [
          { text: 'Clear desk & turn phone on Do Not Disturb', points: 15 },
          { text: 'Complete 45-min Pomodoro study module', points: 35 },
          { text: 'Write down 1 key takeaway summary', points: 15 }
        ]
      },
      {
        title: 'Mindful Evening Decompression',
        category: 'Mindfulness',
        description: 'Clear exam stress with guided breathwork and gratitude.',
        targetDays: 5,
        microGoals: [
          { text: '5-minute box breathing meditation', points: 20 },
          { text: 'Journal 2 wins and 1 thing learned today', points: 20 }
        ]
      },
      {
        title: 'Digital Detox & Sleep Prep',
        category: 'Personal',
        description: 'Unplug screens 30 minutes before sleep for optimal memory retention.',
        targetDays: 7,
        microGoals: [
          { text: 'Put phone in charging dock outside bed range', points: 20 },
          { text: 'Pack backpack & outline top 3 tasks for tomorrow', points: 20 }
        ]
      }
    ],
    'working professional': [
      {
        title: 'Daily Desk Stretch & 8,000 Steps',
        category: 'Fitness',
        description: 'Counteract desk posture and achieve daily step goal.',
        targetDays: 7,
        microGoals: [
          { text: 'Morning 500ml hydration', points: 15 },
          { text: '15-min lunchtime walk or desk stretches', points: 25 },
          { text: 'Evening cool-down walk (3,000 steps)', points: 20 }
        ]
      },
      {
        title: 'Industry Skill Expansion',
        category: 'Learning',
        description: 'Dedicated 25-minute reading or coding to stay ahead in your career.',
        targetDays: 5,
        microGoals: [
          { text: 'Read 1 technical article or watch 1 tech talk', points: 25 },
          { text: 'Log key snippet in personal knowledge base', points: 15 }
        ]
      },
      {
        title: 'Mid-Day Stress Reset & Breathwork',
        category: 'Mindfulness',
        description: 'Lower cortisol levels between high-pressure meetings.',
        targetDays: 5,
        microGoals: [
          { text: 'Close eyes & 3-min box breathing', points: 20 },
          { text: 'Reflect on 1 positive outcome today', points: 15 }
        ]
      },
      {
        title: 'Evening Boundary & Disconnect',
        category: 'Personal',
        description: 'Establish firm work-life balance by shutting down work apps at 6:30 PM.',
        targetDays: 7,
        microGoals: [
          { text: 'Close work Slack/Email tabs at scheduled end-time', points: 20 },
          { text: 'Spend 20 mins on personal hobby or family time', points: 25 }
        ]
      }
    ],
    homemaker: [
      {
        title: 'Morning Wellness & Core Movement',
        category: 'Fitness',
        description: 'Start the day with energizing movement and hydration.',
        targetDays: 7,
        microGoals: [
          { text: 'Hydrate with lemon water on waking', points: 15 },
          { text: '20-min yoga or brisk morning walk', points: 30 }
        ]
      },
      {
        title: 'Personal Learning & Creative Time',
        category: 'Learning',
        description: 'Carve out 30 minutes for an audiobook, course, or creative skill.',
        targetDays: 5,
        microGoals: [
          { text: 'Listen to 20 mins of audiobook or educational podcast', points: 25 },
          { text: 'Note 1 inspiring concept in journal', points: 15 }
        ]
      },
      {
        title: 'Calm Sanctuary Meditation',
        category: 'Mindfulness',
        description: '10 minutes of quiet mindfulness to recharge mental energy.',
        targetDays: 7,
        microGoals: [
          { text: 'Sit in quiet space with tea/coffee for 10 mins', points: 20 },
          { text: 'Write 3 gratitude notes', points: 20 }
        ]
      },
      {
        title: 'Self-Care & Evening Routine',
        category: 'Personal',
        description: 'Dedicated evening self-care to unwind and rejuvenate.',
        targetDays: 7,
        microGoals: [
          { text: 'Skincare or relaxing bath routine', points: 20 },
          { text: 'Set intention and main focus for tomorrow', points: 15 }
        ]
      }
    ]
  };

  const defaultHabits = [
    {
      title: 'Daily Hydration & Movement',
      category: 'Fitness',
      description: 'Maintain high physical energy through consistent movement.',
      targetDays: 7,
      microGoals: [
        { text: 'Drink 2L water throughout day', points: 20 },
        { text: 'Complete 20 minutes active workout or walk', points: 30 }
      ]
    },
    {
      title: 'Focus Skill Sprint',
      category: 'Learning',
      description: 'Acquire new knowledge through structured daily practice.',
      targetDays: 5,
      microGoals: [
        { text: '25-minute uninterrupted study block', points: 30 },
        { text: 'Summarize 1 takeaway', points: 15 }
      ]
    },
    {
      title: 'Mindful Reflection',
      category: 'Mindfulness',
      description: 'Reduce stress and cultivate mental clarity.',
      targetDays: 7,
      microGoals: [
        { text: '5-minute guided deep breathing', points: 20 },
        { text: 'Write down 3 gratitude points', points: 20 }
      ]
    },
    {
      title: 'Nightly Unwind & Digital Detox',
      category: 'Personal',
      description: 'Prepare mind and body for deep restorative sleep.',
      targetDays: 7,
      microGoals: [
        { text: 'Turn off notification alerts at 10 PM', points: 20 },
        { text: 'Read 10 pages of a physical book', points: 20 }
      ]
    }
  ];

  const roleKey = Object.keys(roleTemplates).find(k => role.includes(k) || (role.includes('student') && k === 'student') || (role.includes('professional') && k === 'working professional') || (role.includes('fitness') && k === 'fitness enthusiast') || (role.includes('entrepreneur') && k === 'entrepreneur'));
  const matched = roleTemplates[role] || (roleKey ? roleTemplates[roleKey] : null) || defaultHabits;
  return matched;
}

module.exports = {
  generateMicroGoals,
  generateAccountabilityTip,
  generateOnboardingHabits,
};

