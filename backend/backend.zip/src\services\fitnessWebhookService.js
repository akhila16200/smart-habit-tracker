/**
 * Fitness Tracker Webhook Integration Service
 * Parses incoming fitness activity metrics (Fitbit, Apple Health, Garmin, Generic Webhook)
 * and automatically completes matching micro-goals & checks in habits in DynamoDB.
 */

const habitService = require('./habitService');

class FitnessWebhookService {
  /**
   * Process incoming fitness data payload
   * Example Payload:
   * {
   *   "userId": "USER#default",
   *   "provider": "Fitbit",
   *   "metrics": {
   *     "steps": 8500,
   *     "activeMinutes": 30,
   *     "workoutsCompleted": 1,
   *     "waterMl": 1500,
   *     "caloriesBurned": 450
   *   }
   * }
   */
  async processWebhookPayload(payload) {
    const userId = payload.userId || 'USER#default';
    const provider = payload.provider || 'Generic Wearable';
    const metrics = payload.metrics || payload;

    const steps = metrics.steps || 0;
    const activeMinutes = metrics.activeMinutes || 0;
    const workoutsCompleted = metrics.workoutsCompleted || 0;
    const waterMl = metrics.waterMl || 0;

    // Fetch user habits from DynamoDB / local store
    const userHabits = await habitService.getHabits(userId);
    const todayStr = new Date().toISOString().split('T')[0];

    const autoCompletedMicroGoals = [];
    const autoCheckedInHabits = [];
    const updatedHabitsList = [];

    for (const habit of userHabits) {
      let habitModified = false;
      const microGoals = habit.microGoals || [];

      // Evaluate micro-goals against incoming fitness metrics
      const updatedMicroGoals = microGoals.map(mg => {
        const textLower = mg.text.toLowerCase();
        let shouldComplete = mg.completed;

        // 1. Step count micro-goal matching (e.g., "3,000 steps" or "walk")
        if (textLower.includes('step') || textLower.includes('walk')) {
          // Extract numeric target from micro-goal text if present, default 3000
          const match = textLower.match(/(\d+[\d,]*)\s*step/);
          const targetSteps = match ? parseInt(match[1].replace(/,/g, ''), 10) : 3000;

          if (steps >= targetSteps && !mg.completed) {
            shouldComplete = true;
            autoCompletedMicroGoals.push({
              habitTitle: habit.title,
              microGoalId: mg.id,
              text: mg.text,
              reason: `Step count threshold met (${steps} >= ${targetSteps})`
            });
          }
        }

        // 2. Workout / Active Minutes matching (e.g., "workout", "exercise", "core", "cardio")
        if (textLower.includes('workout') || textLower.includes('exercise') || textLower.includes('cardio') || textLower.includes('core')) {
          if ((workoutsCompleted > 0 || activeMinutes >= 15) && !mg.completed) {
            shouldComplete = true;
            autoCompletedMicroGoals.push({
              habitTitle: habit.title,
              microGoalId: mg.id,
              text: mg.text,
              reason: `Workout completed (${workoutsCompleted} sessions, ${activeMinutes} active mins)`
            });
          }
        }

        // 3. Hydration matching (e.g., "water", "hydrate")
        if (textLower.includes('water') || textLower.includes('hydrate')) {
          const match = textLower.match(/(\d+)\s*ml/);
          const targetWater = match ? parseInt(match[1], 10) : 500;

          if (waterMl >= targetWater && !mg.completed) {
            shouldComplete = true;
            autoCompletedMicroGoals.push({
              habitTitle: habit.title,
              microGoalId: mg.id,
              text: mg.text,
              reason: `Hydration threshold met (${waterMl}ml >= ${targetWater}ml)`
            });
          }
        }

        if (shouldComplete !== mg.completed) {
          habitModified = true;
        }

        return {
          ...mg,
          completed: shouldComplete
        };
      });

      // If micro-goals changed, toggle them in store
      if (habitModified) {
        habit.microGoals = updatedMicroGoals;
        // Check if all micro-goals for this habit are now completed
        const allMicroGoalsDone = updatedMicroGoals.length > 0 && updatedMicroGoals.every(m => m.completed);
        const isAlreadyCheckedIn = (habit.checkInHistory || []).some(entry => entry.date === todayStr);

        // Auto check-in habit if all micro-goals fulfilled and not checked in today
        if (allMicroGoalsDone && !isAlreadyCheckedIn) {
          const checkedInHabit = await habitService.checkInHabit(habit.id, userId);
          autoCheckedInHabits.push({
            habitId: habit.id,
            title: habit.title,
            newStreak: checkedInHabit.currentStreak
          });
          updatedHabitsList.push(checkedInHabit);
        } else {
          // Save updated micro-goals
          for (const mg of updatedMicroGoals) {
            if (mg.completed) {
              await habitService.toggleMicroGoal(habit.id, mg.id, userId);
            }
          }
          updatedHabitsList.push(habit);
        }
      }
    }

    return {
      success: true,
      provider,
      metricsReceived: { steps, activeMinutes, workoutsCompleted, waterMl },
      summary: `Processed fitness metrics from ${provider}. Auto-completed ${autoCompletedMicroGoals.length} micro-goals and auto-checked in ${autoCheckedInHabits.length} habits.`,
      autoCompletedMicroGoals,
      autoCheckedInHabits,
      timestamp: new Date().toISOString()
    };
  }
}

module.exports = new FitnessWebhookService();
