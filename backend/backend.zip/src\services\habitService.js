const { v4: uuidv4 } = require('uuid');
const { docClient, tableName, isLocalMock } = require('../config/dynamodb');
const { PutCommand, GetCommand, QueryCommand, ScanCommand, UpdateCommand, DeleteCommand } = require('@aws-sdk/lib-dynamodb');
const { generateMicroGoals, generateAccountabilityTip, generateOnboardingHabits } = require('./aiService');

// In-Memory Fallback Data Store for immediate out-of-the-box local operation
let inMemoryHabits = [
  {
    id: 'habit-101',
    userId: 'USER#default',
    title: 'Morning 20-Min Deep Work',
    description: 'Zero notifications, high focus reading or coding sprint.',
    category: 'Productivity',
    frequency: 'daily',
    targetDays: 7,
    currentStreak: 5,
    bestStreak: 12,
    totalCheckIns: 18,
    createdAt: new Date(Date.now() - 15 * 86400000).toISOString(),
    lastCheckedInDate: new Date().toISOString().split('T')[0], // Checked in today
    microGoals: [
      { id: 'mg-1', text: 'Put phone in silent mode outside room', points: 10, completed: true },
      { id: 'mg-2', text: 'Set 20-minute focus timer on desk', points: 20, completed: true },
      { id: 'mg-3', text: 'Log 1 key output in daily journal', points: 15, completed: true }
    ],
    checkInHistory: [
      { date: new Date(Date.now() - 4 * 86400000).toISOString().split('T')[0], completedAt: new Date(Date.now() - 4 * 86400000).toISOString() },
      { date: new Date(Date.now() - 3 * 86400000).toISOString().split('T')[0], completedAt: new Date(Date.now() - 3 * 86400000).toISOString() },
      { date: new Date(Date.now() - 2 * 86400000).toISOString().split('T')[0], completedAt: new Date(Date.now() - 2 * 86400000).toISOString() },
      { date: new Date(Date.now() - 1 * 86400000).toISOString().split('T')[0], completedAt: new Date(Date.now() - 1 * 86400000).toISOString() },
      { date: new Date().toISOString().split('T')[0], completedAt: new Date().toISOString() }
    ]
  },
  {
    id: 'habit-102',
    userId: 'USER#default',
    title: 'Hydration & 10k Steps',
    description: 'Drink 3L of water daily and reach step target.',
    category: 'Fitness',
    frequency: 'daily',
    targetDays: 7,
    currentStreak: 3,
    bestStreak: 8,
    totalCheckIns: 14,
    createdAt: new Date(Date.now() - 10 * 86400000).toISOString(),
    lastCheckedInDate: new Date(Date.now() - 1 * 86400000).toISOString().split('T')[0],
    microGoals: [
      { id: 'mg-4', text: 'Drink 500ml water right after waking up', points: 15, completed: true },
      { id: 'mg-5', text: 'Take a 15-minute walking meeting at lunch', points: 25, completed: false },
      { id: 'mg-6', text: 'Evening cool-down walk (3,000 steps)', points: 20, completed: false }
    ],
    checkInHistory: [
      { date: new Date(Date.now() - 3 * 86400000).toISOString().split('T')[0], completedAt: new Date(Date.now() - 3 * 86400000).toISOString() },
      { date: new Date(Date.now() - 2 * 86400000).toISOString().split('T')[0], completedAt: new Date(Date.now() - 2 * 86400000).toISOString() },
      { date: new Date(Date.now() - 1 * 86400000).toISOString().split('T')[0], completedAt: new Date(Date.now() - 1 * 86400000).toISOString() }
    ]
  },
  {
    id: 'habit-103',
    userId: 'USER#default',
    title: 'Mindful Evening Reflection',
    description: 'Unplug 30 mins before sleep and write gratitude entries.',
    category: 'Mindfulness',
    frequency: 'daily',
    targetDays: 5,
    currentStreak: 7,
    bestStreak: 7,
    totalCheckIns: 11,
    createdAt: new Date(Date.now() - 8 * 86400000).toISOString(),
    lastCheckedInDate: new Date().toISOString().split('T')[0],
    microGoals: [
      { id: 'mg-7', text: 'Turn off laptop and screens at 10 PM', points: 15, completed: true },
      { id: 'mg-8', text: 'Journal 3 daily wins & gratitude notes', points: 25, completed: true }
    ],
    checkInHistory: [
      { date: new Date(Date.now() - 6 * 86400000).toISOString().split('T')[0], completedAt: new Date().toISOString() },
      { date: new Date(Date.now() - 5 * 86400000).toISOString().split('T')[0], completedAt: new Date().toISOString() },
      { date: new Date(Date.now() - 4 * 86400000).toISOString().split('T')[0], completedAt: new Date().toISOString() },
      { date: new Date(Date.now() - 3 * 86400000).toISOString().split('T')[0], completedAt: new Date().toISOString() },
      { date: new Date(Date.now() - 2 * 86400000).toISOString().split('T')[0], completedAt: new Date().toISOString() },
      { date: new Date(Date.now() - 1 * 86400000).toISOString().split('T')[0], completedAt: new Date().toISOString() },
      { date: new Date().toISOString().split('T')[0], completedAt: new Date().toISOString() }
    ]
  }
];

/**
 * Helper to calculate current and best streaks dynamically from check-in dates
 */
function recalculateStreak(checkInHistory = []) {
  if (!checkInHistory || checkInHistory.length === 0) {
    return { currentStreak: 0, bestStreak: 0 };
  }

  // Extract unique sorted dates (YYYY-MM-DD) descending
  const dates = Array.from(new Set(checkInHistory.map(h => h.date))).sort().reverse();
  const today = new Date().toISOString().split('T')[0];
  const yesterdayDate = new Date(Date.now() - 86400000).toISOString().split('T')[0];

  let currentStreak = 0;
  let bestStreak = 0;
  let tempStreak = 0;

  // Calculate current streak starting from today or yesterday
  if (dates.includes(today) || dates.includes(yesterdayDate)) {
    let checkDate = dates.includes(today) ? new Date(today) : new Date(yesterdayDate);
    
    while (true) {
      const dateStr = checkDate.toISOString().split('T')[0];
      if (dates.includes(dateStr)) {
        currentStreak++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        break;
      }
    }
  }

  // Calculate best streak historically
  const sortedAsc = Array.from(new Set(checkInHistory.map(h => h.date))).sort();
  if (sortedAsc.length > 0) {
    tempStreak = 1;
    bestStreak = 1;
    for (let i = 1; i < sortedAsc.length; i++) {
      const prev = new Date(sortedAsc[i - 1]);
      const curr = new Date(sortedAsc[i]);
      const diffDays = Math.round((curr - prev) / (1000 * 60 * 60 * 24));

      if (diffDays === 1) {
        tempStreak++;
      } else if (diffDays > 1) {
        tempStreak = 1;
      }
      if (tempStreak > bestStreak) {
        bestStreak = tempStreak;
      }
    }
  }

  return {
    currentStreak,
    bestStreak: Math.max(bestStreak, currentStreak)
  };
}

class HabitService {
  /**
   * Get all habits for user
   */
  async getHabits(userId = 'USER#default') {
    if (isLocalMock || !docClient) {
      let userHabits = inMemoryHabits.filter(h => h.userId === userId);
      // Seed default habits for new users in local mode
      if (userHabits.length === 0 && userId !== 'USER#default') {
        const seededHabits = [
          {
            id: `habit-${uuidv4().substring(0, 8)}`,
            userId,
            PK: userId,
            SK: `HABIT#seeded-1`,
            title: 'Daily Deep Coding & Study',
            description: 'Focused 45-min coding or reading session.',
            category: 'Learning',
            frequency: 'daily',
            targetDays: 7,
            currentStreak: 2,
            bestStreak: 5,
            totalCheckIns: 4,
            createdAt: new Date().toISOString(),
            lastCheckedInDate: new Date(Date.now() - 1 * 86400000).toISOString().split('T')[0],
            microGoals: [
              { id: 'smg-1', text: 'Clear desktop & set 45-min focus timer', points: 15, completed: true },
              { id: 'smg-2', text: 'Execute core module sprint without phone', points: 30, completed: false }
            ],
            checkInHistory: [
              { date: new Date(Date.now() - 2 * 86400000).toISOString().split('T')[0], completedAt: new Date().toISOString() },
              { date: new Date(Date.now() - 1 * 86400000).toISOString().split('T')[0], completedAt: new Date().toISOString() }
            ]
          }
        ];
        inMemoryHabits.push(...seededHabits);
        userHabits = seededHabits;
      }

      return userHabits.map(h => ({
        ...h,
        tip: generateAccountabilityTip(h.title, h.currentStreak)
      }));
    }

    try {
      const command = new QueryCommand({
        TableName: tableName,
        KeyConditionExpression: 'PK = :pk AND begins_with(SK, :skPrefix)',
        ExpressionAttributeValues: {
          ':pk': userId,
          ':skPrefix': 'HABIT#'
        }
      });
      const response = await docClient.send(command);
      const items = response.Items || [];
      return items.map(item => ({
        ...item,
        tip: generateAccountabilityTip(item.title, item.currentStreak || 0)
      }));
    } catch (err) {
      console.warn('[DynamoDB] Query failed, using local fallback:', err.message);
      let userHabits = inMemoryHabits.filter(h => h.userId === userId);
      return userHabits.map(h => ({
        ...h,
        tip: generateAccountabilityTip(h.title, h.currentStreak)
      }));
    }
  }

  /**
   * Get habit by ID
   */
  async getHabitById(id, userId = 'USER#default') {
    if (isLocalMock || !docClient) {
      return inMemoryHabits.find(h => h.id === id) || null;
    }

    try {
      const command = new GetCommand({
        TableName: tableName,
        Key: {
          PK: userId,
          SK: `HABIT#${id}`
        }
      });
      const response = await docClient.send(command);
      return response.Item || null;
    } catch (err) {
      console.warn('[DynamoDB] GetItem failed, searching fallback:', err.message);
      return inMemoryHabits.find(h => h.id === id) || null;
    }
  }

  /**
   * Create a new Habit
   */
  async createHabit(habitData, userId = 'USER#default') {
    const habitId = `habit-${uuidv4().substring(0, 8)}`;
    const now = new Date().toISOString();

    const microGoals = habitData.microGoals && habitData.microGoals.length > 0
      ? habitData.microGoals
      : generateMicroGoals(habitData.title, habitData.category);

    const newHabit = {
      PK: userId,
      SK: `HABIT#${habitId}`,
      id: habitId,
      userId,
      title: habitData.title,
      description: habitData.description || '',
      category: habitData.category || 'Personal',
      frequency: habitData.frequency || 'daily',
      targetDays: habitData.targetDays || 7,
      currentStreak: 0,
      bestStreak: 0,
      totalCheckIns: 0,
      lastCheckedInDate: null,
      createdAt: now,
      microGoals,
      checkInHistory: []
    };

    if (isLocalMock || !docClient) {
      inMemoryHabits.unshift(newHabit);
      return newHabit;
    }

    try {
      const command = new PutCommand({
        TableName: tableName,
        Item: newHabit
      });
      await docClient.send(command);
      return newHabit;
    } catch (err) {
      console.warn('[DynamoDB] PutItem failed, adding to memory fallback:', err.message);
      inMemoryHabits.unshift(newHabit);
      return newHabit;
    }
  }

  /**
   * Daily Check-In for a Habit
   */
  async checkInHabit(id, userId = 'USER#default') {
    const habit = await this.getHabitById(id, userId);
    if (!habit) {
      throw new Error('Habit not found');
    }

    const todayStr = new Date().toISOString().split('T')[0];
    const checkInHistory = habit.checkInHistory || [];

    // Check if already checked in today
    const alreadyCheckedIn = checkInHistory.some(entry => entry.date === todayStr);

    let updatedHistory;
    if (alreadyCheckedIn) {
      // Toggle check-in off if requested again
      updatedHistory = checkInHistory.filter(entry => entry.date !== todayStr);
    } else {
      // Add check-in
      updatedHistory = [...checkInHistory, { date: todayStr, completedAt: new Date().toISOString() }];
    }

    // Recalculate streaks
    const { currentStreak, bestStreak } = recalculateStreak(updatedHistory);
    const lastCheckedInDate = updatedHistory.length > 0 ? updatedHistory[updatedHistory.length - 1].date : null;

    // Reset microgoals completed status if checked off or mark all as done
    const updatedMicroGoals = (habit.microGoals || []).map(mg => ({
      ...mg,
      completed: !alreadyCheckedIn
    }));

    const updatedFields = {
      ...habit,
      checkInHistory: updatedHistory,
      currentStreak,
      bestStreak: Math.max(habit.bestStreak || 0, bestStreak),
      totalCheckIns: updatedHistory.length,
      lastCheckedInDate,
      microGoals: updatedMicroGoals
    };

    if (isLocalMock || !docClient) {
      const idx = inMemoryHabits.findIndex(h => h.id === id);
      if (idx !== -1) {
        inMemoryHabits[idx] = updatedFields;
      }
      return updatedFields;
    }

    try {
      const command = new PutCommand({
        TableName: tableName,
        Item: updatedFields
      });
      await docClient.send(command);
      return updatedFields;
    } catch (err) {
      console.warn('[DynamoDB] Checkin update failed, saving in memory:', err.message);
      const idx = inMemoryHabits.findIndex(h => h.id === id);
      if (idx !== -1) {
        inMemoryHabits[idx] = updatedFields;
      }
      return updatedFields;
    }
  }

  /**
   * Toggle Micro-Goal Completion
   */
  async toggleMicroGoal(habitId, microGoalId, userId = 'USER#default') {
    const habit = await this.getHabitById(habitId, userId);
    if (!habit) {
      throw new Error('Habit not found');
    }

    const microGoals = habit.microGoals || [];
    const updatedMicroGoals = microGoals.map(mg => {
      if (mg.id === microGoalId) {
        return { ...mg, completed: !mg.completed };
      }
      return mg;
    });

    const updatedFields = {
      ...habit,
      microGoals: updatedMicroGoals
    };

    if (isLocalMock || !docClient) {
      const idx = inMemoryHabits.findIndex(h => h.id === habitId);
      if (idx !== -1) {
        inMemoryHabits[idx] = updatedFields;
      }
      return updatedFields;
    }

    try {
      const command = new PutCommand({
        TableName: tableName,
        Item: updatedFields
      });
      await docClient.send(command);
      return updatedFields;
    } catch (err) {
      console.warn('[DynamoDB] MicroGoal update failed:', err.message);
      const idx = inMemoryHabits.findIndex(h => h.id === habitId);
      if (idx !== -1) {
        inMemoryHabits[idx] = updatedFields;
      }
      return updatedFields;
    }
  }

  /**
   * Delete Habit
   */
  async deleteHabit(id, userId = 'USER#default') {
    if (isLocalMock || !docClient) {
      inMemoryHabits = inMemoryHabits.filter(h => h.id !== id);
      return { success: true, id };
    }

    try {
      const command = new DeleteCommand({
        TableName: tableName,
        Key: {
          PK: userId,
          SK: `HABIT#${id}`
        }
      });
      await docClient.send(command);
      return { success: true, id };
    } catch (err) {
      console.warn('[DynamoDB] DeleteItem failed, deleting from fallback memory:', err.message);
      inMemoryHabits = inMemoryHabits.filter(h => h.id !== id);
      return { success: true, id };
    }
  }

  /**
   * Update Habit Details (Title, Category, TargetDays, Description, MicroGoals)
   */
  async updateHabit(id, updateData, userId = 'USER#default') {
    const existing = await this.getHabitById(id, userId);
    if (!existing) {
      throw new Error('Habit not found');
    }

    const updatedItem = {
      ...existing,
      title: updateData.title !== undefined ? updateData.title : existing.title,
      description: updateData.description !== undefined ? updateData.description : existing.description,
      category: updateData.category !== undefined ? updateData.category : existing.category,
      targetDays: updateData.targetDays !== undefined ? parseInt(updateData.targetDays, 10) : existing.targetDays,
      frequency: updateData.frequency !== undefined ? updateData.frequency : existing.frequency,
      microGoals: updateData.microGoals !== undefined ? updateData.microGoals : existing.microGoals
    };

    if (isLocalMock || !docClient) {
      const idx = inMemoryHabits.findIndex(h => h.id === id);
      if (idx !== -1) {
        inMemoryHabits[idx] = updatedItem;
      }
      return updatedItem;
    }

    try {
      const command = new PutCommand({
        TableName: tableName,
        Item: updatedItem
      });
      await docClient.send(command);
      return updatedItem;
    } catch (err) {
      console.warn('[DynamoDB] UpdateItem failed, updating memory fallback:', err.message);
      const idx = inMemoryHabits.findIndex(h => h.id === id);
      if (idx !== -1) {
        inMemoryHabits[idx] = updatedItem;
      }
      return updatedItem;
    }
  }

  /**
   * Batch Generate & Create Onboarding AI Habits
   */
  async createOnboardingHabits(profile, userId = 'USER#default') {
    const generated = generateOnboardingHabits(profile);
    const createdHabits = [];

    for (const item of generated) {
      const habit = await this.createHabit({
        title: item.title,
        description: item.description,
        category: item.category,
        targetDays: item.targetDays,
        microGoals: item.microGoals
      }, userId);
      createdHabits.push(habit);
    }

    return createdHabits;
  }
}

module.exports = new HabitService();
