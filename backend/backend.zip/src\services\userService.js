const crypto = require('crypto');
const { docClient, tableName, isLocalMock } = require('../config/dynamodb');
const { PutCommand, GetCommand } = require('@aws-sdk/lib-dynamodb');

// In-Memory User Fallback
let inMemoryUsers = [
  {
    id: 'USER#default',
    email: 'demo@habitpulse.io',
    name: 'Demo Hackathon User',
    passwordHash: hashPassword('password123'),
    createdAt: new Date().toISOString()
  }
];

function hashPassword(password) {
  return crypto.createHash('sha256').update(password + 'smart_habit_salt_2026').digest('hex');
}

class UserService {
  async signup(name, email, password) {
    const formattedEmail = email.toLowerCase().trim();
    const userId = `USER#${formattedEmail}`;

    const existing = await this.getUserByEmail(formattedEmail);
    if (existing) {
      throw new Error('User with this email already exists.');
    }

    const newUser = {
      PK: userId,
      SK: 'PROFILE',
      id: userId,
      name,
      email: formattedEmail,
      passwordHash: hashPassword(password),
      createdAt: new Date().toISOString(),
      connectedWearables: {
        fitbit: { connected: true, lastSynced: new Date().toISOString(), device: 'Fitbit Charge 6' },
        appleHealth: { connected: false, lastSynced: null, device: 'Apple Watch Series 9' },
        googleFit: { connected: false, lastSynced: null, device: 'Pixel Watch 2' }
      }
    };

    if (isLocalMock || !docClient) {
      inMemoryUsers.push(newUser);
      return this.sanitizeUser(newUser);
    }

    try {
      const command = new PutCommand({
        TableName: tableName,
        Item: newUser
      });
      await docClient.send(command);
      return this.sanitizeUser(newUser);
    } catch (err) {
      console.warn('[DynamoDB] Signup failed, saving in memory fallback:', err.message);
      inMemoryUsers.push(newUser);
      return this.sanitizeUser(newUser);
    }
  }

  async login(email, password) {
    const formattedEmail = email.toLowerCase().trim();
    const user = await this.getUserByEmail(formattedEmail);

    if (!user) {
      throw new Error('Invalid email or password.');
    }

    const inputHash = hashPassword(password);
    if (user.passwordHash !== inputHash) {
      throw new Error('Invalid email or password.');
    }

    return this.sanitizeUser(user);
  }

  async getUserByEmail(email) {
    const formattedEmail = email.toLowerCase().trim();
    const userId = `USER#${formattedEmail}`;

    if (isLocalMock || !docClient) {
      return inMemoryUsers.find(u => u.email === formattedEmail) || null;
    }

    try {
      const command = new GetCommand({
        TableName: tableName,
        Key: {
          PK: userId,
          SK: 'PROFILE'
        }
      });
      const res = await docClient.send(command);
      return res.Item || inMemoryUsers.find(u => u.email === formattedEmail) || null;
    } catch (err) {
      console.warn('[DynamoDB] GetUser failed, searching fallback memory:', err.message);
      return inMemoryUsers.find(u => u.email === formattedEmail) || null;
    }
  }

  async getUserById(userId) {
    if (isLocalMock || !docClient) {
      return inMemoryUsers.find(u => u.id === userId) || null;
    }

    try {
      const command = new GetCommand({
        TableName: tableName,
        Key: {
          PK: userId,
          SK: 'PROFILE'
        }
      });
      const res = await docClient.send(command);
      return res.Item ? this.sanitizeUser(res.Item) : inMemoryUsers.find(u => u.id === userId) || null;
    } catch (err) {
      console.warn('[DynamoDB] GetUserById failed:', err.message);
      const found = inMemoryUsers.find(u => u.id === userId);
      return found ? this.sanitizeUser(found) : null;
    }
  }

  async updateUserProfile(userId, profileData) {
    let user = await this.getUserById(userId);
    if (!user) {
      user = {
        PK: userId,
        SK: 'PROFILE',
        id: userId,
        name: profileData.name || 'User',
        email: profileData.email || 'user@example.com',
        role: profileData.role || 'Working Professional',
        primaryGoal: profileData.primaryGoal || 'Improve daily productivity & balance',
        createdAt: new Date().toISOString()
      };
    }

    const updatedUser = {
      ...user,
      name: profileData.name !== undefined ? profileData.name : user.name,
      email: profileData.email !== undefined ? profileData.email.toLowerCase().trim() : user.email,
      role: profileData.role !== undefined ? profileData.role : (user.role || 'Working Professional'),
      primaryGoal: profileData.primaryGoal !== undefined ? profileData.primaryGoal : (user.primaryGoal || 'Improve daily productivity'),
      preferences: {
        ...(user.preferences || {}),
        ...(profileData.preferences || {})
      },
      updatedAt: new Date().toISOString()
    };

    if (isLocalMock || !docClient) {
      const idx = inMemoryUsers.findIndex(u => u.id === userId);
      if (idx !== -1) {
        inMemoryUsers[idx] = { ...inMemoryUsers[idx], ...updatedUser };
      } else {
        inMemoryUsers.push(updatedUser);
      }
      return this.sanitizeUser(updatedUser);
    }

    try {
      const command = new PutCommand({
        TableName: tableName,
        Item: updatedUser
      });
      await docClient.send(command);
      return this.sanitizeUser(updatedUser);
    } catch (err) {
      console.warn('[DynamoDB] updateUserProfile failed, updating memory store:', err.message);
      const idx = inMemoryUsers.findIndex(u => u.id === userId);
      if (idx !== -1) {
        inMemoryUsers[idx] = { ...inMemoryUsers[idx], ...updatedUser };
      } else {
        inMemoryUsers.push(updatedUser);
      }
      return this.sanitizeUser(updatedUser);
    }
  }

  sanitizeUser(user) {
    const { passwordHash, ...sanitized } = user;
    return sanitized;
  }
}


module.exports = new UserService();
